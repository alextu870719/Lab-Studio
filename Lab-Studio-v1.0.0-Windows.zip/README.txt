Lab Studio - Windows版本
==========================

這是Lab Studio的Windows版本，一個專業的實驗室實驗設計和計算工具包。

運行方法：
---------
1. 確保所有文件都在同一個資料夾中
2. 雙擊 lab_studio.exe 來啟動應用程式

系統需求：
---------
- Windows 10或更新版本
- 64位作業系統

文件說明：
---------
- lab_studio.exe: 主執行檔
- flutter_windows.dll: Flutter運行時庫
- pdfium.dll: PDF處理庫
- printing_plugin.dll: 列印功能插件
- data/: 應用程式資源文件

注意事項：
---------
- 請不要移動或刪除任何文件，否則應用程式可能無法正常運行
- 如果遇到問題，請確保所有文件都在同一個資料夾中

版本：1.0.0
構建日期：2025年6月28日
